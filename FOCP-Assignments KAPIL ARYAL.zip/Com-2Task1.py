print("""Stop! Who would cross the Bridge of Death
Must answer me these questions three, 'ere the other side he see.""")
name=input("What is your name? :\n")
if (name =="Arthur" or name=="arthur"):
    print("My liege! You may pass!")
else:
    destination= input("What do you seek?")

    if ("grail" not in destination.lower()):                    #1.If grail is not present in string"Destination= used as dest"
        print("Only those who seek the Grail may pass.")   #If no. 1 This output will be executed
    else:
        favouriteC=input("What is your favourite colour?")
        if (name[0].lower()==favpuriteC[0].lower()):     #2 compares if the First letter of the name and favourite colour 
                                                          #provided by the user is the same as the name of the are equal
            print("You may pass!")                        #If no.2 this output will be executed
        else:
            print("Incorrect! You must now face the Gorge of Eternal Peril.")  # if not no.2 this statement will be executed