from league import League
import sys
 
def main():
    league = League()
    if 1 < len(sys.argv):
        #sets name of league
        league.set_name(sys.argv[1])
    #passing team name and results along with league
    league.parse_teams("teams.txt")
    league.parse_matches("results.txt")
    league.get_league_table() #Returns the output table from league module
    
if __name__ == "__main__":
    main()