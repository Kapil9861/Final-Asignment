class Team:
    def __init__(self, name):
        self.name = name
        self.scores = []
        self.againsts = []
        
    def get_name(self):
        # Get team name
        return self.name
    
    def total_played(self):
        # Total matches played
        return len(self.scores)
    
    def total_score(self):
        # Get total score
        return sum(self.scores) 
    
    def total_against(self):
        # Get total goal against the team
        return sum(self.againsts)
    
    def get_difference(self):
        # Get total goal scored - total goal against
        return self.total_score() - self.total_against()
    
    def add_scores(self, score, against):
        # stores goal scores and goal taken of one match
        self.scores.append(int(score))
        self.againsts.append(int(against))
    
    def total_wins(self):
        # Get total wins by team
        count = 0
        for score, against in zip(self.scores, self.againsts):
            count = count + (1 if (score - against) > 0 else 0)
        return count

    def total_loss(self):
        # Get total loss by team
        count = 0
        for score, against in zip(self.scores, self.againsts):
            count = count + (1 if (score - against) < 0 else 0)
        return count
    
    def total_draws(self):
        # Get total draws by team
        total_matches = len(self.scores)
        return total_matches - (self.total_wins() + self.total_loss()) # returns total matches played minus wins and losses

    def calculate_points(self):
        #Get total points earned by team wins and draws
        return self.total_wins() * 3 + self.total_draws()
class League:
    def __init__(self):
        self.teams = []
        self.name = ""
    
    def set_name(self, name):
        #Name of league to be printed
        self.name = name
    
    def parse_teams(self, file):
        #Teams playing on the league parsed from a file
        f = open(file, "r")
        for team in f:
            self.teams.append(Team(team.strip()))
            
    def parse_matches(self, file):
        #Gets score of team in a match from file and stores it
        f = open(file, "r")
        for match in f:
            match_list = match.split(",")
            for team in self.teams:
                if (team.name == match_list[0]): 
                    team.add_scores(match_list[1], match_list[3])
                    
                elif (team.name == match_list[2]): 
                    team.add_scores(match_list[3], match_list[1])
    
    def get_league_table(self):
        #displays output table
        if self.name != "":
            #shows league name as output
            print("\n" + self.name)
            print("=" * len(self.name) + "\n")
        print("            P  W  D  L    {0:4} {1} {2:6} {3}".format("F", "A", "Diff", "Pts"))
        self.teams.sort(key=lambda x: x.get_difference(), reverse=True)
        for team in self.teams:
            print("{0:<20}{1} {2:2} {3:2} {4:2} {5:4} {6:4} {7:4} {8:4}".format(team.get_name(), team.total_played(), team.total_wins(), team.total_draws(), team.total_loss(), team.total_score(), team.total_against(), team.get_difference(), team.calculate_points()))
                
    def displayTeams(self):
        #displays team names
        print(self.teams)