import random                                         #importing module random
print("""Welcome to Pop Chat
One of our operators will be pleased to help you today.\n""")       #following the instructions by client
email = input("Please enter your Poppleton email address: ")
name=email[:-10]                                         #taking part of email and stored in vanrable "name"
handler=['John','Janice','Fiona','Arthur']             #for random assistant for campus chat system
no_f=["Hmmmm","Oh,yes,I see","Tell me more. ","Uhmmm"]    #for random chat for other than default input from user
go_out=["exit","help","bye","goodbye","quit"]

if "@pop.ac.uk" in email and email.count("@")==1:           #if statement executes if count of @ is equal to 1 and is provided with valid extension of email
    print(" Hi, ",name.capitalize(),"! Thank you, and Welcome to PopChat!")  #for welcoming user
    print("My name is ",random.choice(handler)," and it will be my pleasure to help you.")
    a=range(0,10) 
    for i in a:                                        #for 10% error system
        if random.choice(a)==1:
            print("***NETWORK ERROR *** \n\n")
            break
        else:                                          #for the chat system when there is no network error
            question=input("--->").lower()
            while question not in go_out:             #if the user inputs any input other than the words in "go_out" list, this section will execute
                 ####//  INSIDE THE CHAT SYSTEM   //###
                if "library" in question:         
                    print("The library is closed today.")
                    question=input("--->").lower()
                elif "wifi" in question:
                    print("WiFi is excellent across the campus.")
                    question=input("--->").lower()
                elif "deadline" in question:
                    print("Your deadline has been extended by two working days.")
                    question=input("--->").lower()
                elif "football" in question:
                    print("Yes, it is available after classes.")
                    question=input("--->").lower()
                elif "nice" in question:
                    print("Thank you very much.")
                    question=input("--->").lower()
                elif "No" in question:
                    print("Why not? Please elaborate,will you?")
                    question=input("--->").lower()
                elif "really" in question:
                    print("Yes, it is.")
                    question=input("--->").lower()
                elif "complain" in question:
                    print("Thank you for your complain, this conversation will not be saved and action will be taken promptly.")
                    question=input("--->").lower()     
                elif question == "":              #if not words is provided this will execute
                    print("Please give command, so that I can help you.")
                    question=input("--->").lower()
                elif question!="":                     #if any words other than the strings in above elif statement is
                                                        # provided this will execute
                    print(random.choice(no_f))
                    question=input("--->").lower()
                elif "go_out" in question:
                    print(random.choice(no_f))
                    question=input("--->").lower()
            break                                                       #this will break the for loop

    print("Thanks, ",name.capitalize(),", for using PopChat. See you again soon!")
elif len(name)< 2:                             #If the length of name i.e. before @ is less than 2 characters it will execute
    print("Invalid name provided in the email, the name with",name,"doesn't exist in the Campus.")
else:                                            #If there is not valid email extensioni.e."@pop.ac.uk" this will execute
    print("Invalid Email address please provided the working one. Thank You!")