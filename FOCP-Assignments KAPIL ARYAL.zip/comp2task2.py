print("Swallow Speed Analysis: Version 1.0")
readings=input("Enter the next reading: ")
U_list=[]       #declaring lists
E_list=[]
fElist=[]
fUlist=[]
c2Ulist=[]
c2Elist=[]
totalE=0         #declaring variables for storing added values
totalU=0
totalkm=0
totalM=0
totalUkm=0
totalEm=0
if ("E") in readings:               #It executes if reading contains "E" in it
    print("Reading saved.")
    E_list.append(float(readings[1:]))            #Value with "E" is stored in here       
    while readings:                                #When reading is provided this loop will be activated and is
                                                      #  stored in seperate list for each U or E     
        readings=input("Enter the next reading: ")  
        print("Reading saved.")
        if "E" in readings:
            E_list.append(float(readings[1:]))
            
        elif "U" in readings:
            U_list.append(float(readings[1:]))
            
        else:                                     #If E or U is not mentioned this executes
            break;               
    for item in E_list:                             #Conversion KMH to MPH or vice versa
        totalE+=item
        totalEm=totalE* (1.61)

    for item in U_list:
        totalU+=item
        totalUkm=totalU/(1.61)
    c2Ulist=[element /1.61 for element in E_list]               #Conversion KMH to MPH and vice versa
    c2Elist=[element *1.61 for element in U_list]
    fElist=c2Elist+E_list
    fUlist=c2Ulist+U_list
    totalkm=totalE+totalUkm
    totalM=totalU+totalEm
    averageE=totalkm/len(fElist)                              # Average in KPH and MPH
    averageU=totalM/len(fUlist)
    print("  ",len(fElist),"Readings Analysed.")
    print("Max Speed:  ", round(max(fUlist),2),"MPH, ",round(max(fElist),2),"KPH.")        #Output as requested
    print("Min Speed:  ", round(min(fUlist),2),"MPH, ",round(min(fElist),2),"KPH.")
    print("Avg Speed: ", round(averageE,2),"MPH, ",round(averageU,2),"KPH.")


elif ("U") in readings:               #It executes if reading contains "U" in it
    print("Reading saved.")
    U_list.append(float(readings[1:]))         #Value with "E" is stored in here             
    while readings:                                       #When reading is provided this loop will be activated and is
                                                      #  stored in seperate list for each U or E  
        readings=input("Enter the next reading: ")
        print("Reading saved.")
        if "E" in readings:
            E_list.append(float(readings[1:]))
            
        elif "U" in readings:
            U_list.append(float(readings[1:]))
            
        else:                                                      #If E or U is not mentioned this executes
            break;
    for item in E_list:                                             #Conversion KMH to MPH and vice versa
        totalE+=item
        totalEm=totalE* (1.61)

    for item in U_list:
        totalU+=item
        totalUkm=totalU/(1.61)
    c2Ulist=[element /1.61 for element in E_list]
    c2Elist=[element *1.61 for element in U_list]
    fElist=c2Elist+E_list
    fUlist=c2Ulist+U_list
    totalkm=totalE+totalUkm
    totalM=totalU+totalEm
    averageE=totalkm/len(fElist)                                                        # Average in KPH and MPH
    averageU=totalM/len(fUlist)
    print("  ",len(fElist),"Readings Analysed.")
    print("Max Speed:  ", round(max(fUlist),2),"MPH, ",round(max(fElist),2),"KPH.")           #Output as requested
    print("Min Speed:  ", round(min(fUlist),2),"MPH, ",round(min(fElist),2),"KPH.")
    print("Avg Speed: ", round(averageE,2),"MPH, ",round(averageU,2),"KPH.")           
else:                                                                           #It executes if neither E nor U is provided at start
    print("No readings entered. Nothing to do.")